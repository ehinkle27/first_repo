num = int(input("Enter a number:  "))

if num < 0:
    print("The inputted number is negative.")
elif num > 0:
    print("The inputted number is positive.")
else:
    print("The inputted number is zero.")
