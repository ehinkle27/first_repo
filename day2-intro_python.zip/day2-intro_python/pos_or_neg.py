x = int(input("Enter a number:  "))
y = int(input("Enter another number:  "))

if x > y:
    print("The first number is larger")
elif x < y:
    print("The second number is larger")
else:
    print("The numbers are equal")
