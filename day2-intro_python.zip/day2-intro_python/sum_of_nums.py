num = int(input("Input a number:  ")

sum_of_nums = 0
i = num

while i > 0:
    sum_of_nums += i
    i -= 1
